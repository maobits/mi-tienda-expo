import React from "react";
import { Image, StyleSheet, View, ImageStyle } from "react-native";

interface SnackLogoProps {
  size?: number; // tamaño opcional
  style?: ImageStyle; // estilos opcionales adicionales
}

export default function SnackLogo({ size = 100, style }: SnackLogoProps) {
  return (
    <View style={styles.container}>
      <Image
        source={require("../../../assets/brand_kit/logo.png")}
        style={[{ width: size, height: size, resizeMode: "contain" }, style]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    justifyContent: "center",
  },
});
