import React from "react";
import { View, StyleSheet, Linking } from "react-native";
import { Text, Icon } from "react-native-paper";
import { useTheme } from "../../estilo/ThemeContext";

interface Props {
  company: string;
  url: string;
}

export default function SnackCopyright({ company, url }: Props) {
  const { colors, fonts, fontSizes } = useTheme();

  const abrirEnlace = async () => {
    const soportado = await Linking.canOpenURL(url);
    if (soportado) {
      await Linking.openURL(url);
    } else {
      console.warn("No se puede abrir la URL:", url);
    }
  };

  return (
    <View style={styles.container}>
      <Icon source="copyright" size={16} color={colors.muted} />
      <Text
        style={{
          color: colors.muted,
          fontSize: fontSizes.sm,
          fontFamily: fonts.main,
          marginLeft: 4,
        }}
      >
        Creado por{" "}
        <Text
          onPress={abrirEnlace}
          style={{
            color: colors.primary,
            fontFamily: fonts.heading,
            textDecorationLine: "underline",
          }}
        >
          {company}
        </Text>
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
});
