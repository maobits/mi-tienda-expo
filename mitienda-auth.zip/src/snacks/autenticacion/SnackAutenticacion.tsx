import React, { useState } from "react";
import { View, StyleSheet, Alert } from "react-native";
import { TextInput, Button, Card, Text } from "react-native-paper";
import { iniciarSesion } from "../../recetas/autenticacion/auth";
import { useTheme } from "../../estilo/ThemeContext";

export default function SnackAutenticacion() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { colors, fonts, fontSizes } = useTheme(); // 🎨 Tema global

  const validarCampos = () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert(
        "⚠️ Campos incompletos",
        "Por favor ingresa tu correo y contraseña."
      );
      return false;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      Alert.alert(
        "⚠️ Correo inválido",
        "Ingresa un correo electrónico válido."
      );
      return false;
    }

    return true;
  };

  const controladorInicioSesion = async () => {
    if (!validarCampos()) return;

    try {
      await iniciarSesion(email, password);
      Alert.alert("✅ Sesión iniciada correctamente.");
      console.log("Sesión iniciada correctamente.");
    } catch (error: any) {
      Alert.alert("❌ Error", error.message);
      console.log("Error", error.message);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <Card style={styles.card}>
        <Card.Title
          title="Iniciar Sesión"
          titleStyle={{
            fontFamily: fonts.heading,
            fontSize: fontSizes.lg,
            color: colors.text,
            textAlign: "center",
          }}
        />
        <Card.Content>
          <TextInput
            label="Correo electrónico"
            mode="outlined"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
            style={[styles.input, { fontFamily: fonts.main }]}
            outlineColor={colors.border}
            activeOutlineColor={colors.primary}
            theme={{
              colors: { text: colors.text, placeholder: colors.placeholder },
            }}
          />
          <TextInput
            label="Contraseña"
            mode="outlined"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            style={[styles.input, { fontFamily: fonts.main }]}
            outlineColor={colors.border}
            activeOutlineColor={colors.primary}
            theme={{
              colors: { text: colors.text, placeholder: colors.placeholder },
            }}
          />
        </Card.Content>
        <Card.Actions style={styles.actions}>
          <Button
            mode="contained"
            onPress={controladorInicioSesion}
            style={[
              styles.button,
              { backgroundColor: colors.primary, alignSelf: "center" },
            ]}
            labelStyle={{
              color: colors.white,
              fontFamily: fonts.heading,
              fontSize: fontSizes.md,
            }}
          >
            Iniciar Sesión
          </Button>
        </Card.Actions>
      </Card>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    alignItems: "center",
  },
  card: {
    width: "100%",
    borderRadius: 16,
    elevation: 4,
    paddingVertical: 16,
  },
  input: {
    marginBottom: 16,
  },
  actions: {
    flexDirection: "column",
    alignItems: "center",
    paddingHorizontal: 16,
    marginTop: 8,
  },
  button: {
    borderRadius: 12,
  },
});
