import React, { createContext, useContext, ReactNode } from "react";

interface Theme {
  colors: {
    primary: string; // Color principal
    secondary: string; // Acento o acción secundaria
    surface: string; // Fondo de tarjetas, inputs, etc.
    background: string; // Fondo general de la app
    text: string; // Texto principal
    muted: string; // Texto menos importante
    white: string;
    black: string;
    success: string;
    danger: string;
    warning: string;
    info: string;
    border: string;
    placeholder: string;
  };
  fonts: {
    main: string;
    heading: string;
  };
  fontSizes: {
    xs: number;
    sm: number;
    md: number;
    lg: number;
    xl: number;
  };
}

const defaultTheme: Theme = {
  colors: {
    primary: "#3B82F6", // Azul moderno (Material)
    secondary: "#F59E0B", // Naranja vibrante
    surface: "#F9FAFB", // Fondo claro y limpio para tarjetas
    background: "#FFFFFF", // Fondo general claro
    text: "#1F2937", // Texto oscuro elegante
    muted: "#6B7280", // Texto gris neutro
    white: "#FFFFFF",
    black: "#000000",
    success: "#10B981", // Verde esmeralda (éxito)
    danger: "#EF4444", // Rojo moderno (error)
    warning: "#FBBF24", // Amarillo suave (advertencia)
    info: "#0EA5E9", // Azul cielo (información)
    border: "#E5E7EB", // Borde sutil gris claro
    placeholder: "#9CA3AF", // Placeholder gris moderno
  },

  fonts: {
    main: "Inter-Regular",
    heading: "Raleway-Bold",
  },
  fontSizes: {
    xs: 10,
    sm: 12,
    md: 16,
    lg: 20,
    xl: 24,
  },
};

// Crear el contexto
const ThemeContext = createContext<Theme>(defaultTheme);

// Proveedor
export const ThemeProvider = ({ children }: { children: ReactNode }) => (
  <ThemeContext.Provider value={defaultTheme}>{children}</ThemeContext.Provider>
);

// Hook personalizado
export const useTheme = () => useContext(ThemeContext);
