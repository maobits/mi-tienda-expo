import React from "react";
import { SafeAreaView, View, StyleSheet, Dimensions } from "react-native";
import { Card, Text } from "react-native-paper";
import SnackAutenticacion from "../../snacks/autenticacion/SnackAutenticacion";
import SnackLogo from "../../snacks/brand_kit/SnackLogo";
import { useTheme } from "../../estilo/ThemeContext";
import SnackCopyright from "../../snacks/brand_kit/SnackCopyright";

export default function PantallaAutenticacion() {
  const { colors, fonts, fontSizes } = useTheme();
  const screenWidth = Dimensions.get("window").width;

  return (
    <SafeAreaView
      style={[styles.container, { backgroundColor: colors.background }]}
    >
      {/* Fondo superior redondeado con logo */}
      <View style={[styles.topBackground, { backgroundColor: colors.primary }]}>
        <SnackLogo size={120} />
        <Text
          style={{
            marginTop: 8,
            fontFamily: fonts.heading,
            fontSize: fontSizes.lg,
            color: colors.white,
            letterSpacing: 1,
          }}
        >
          MI TIENDA EN LÍNEA
        </Text>
      </View>

      <View style={styles.content}>
        <Card
          style={[
            styles.card,
            {
              backgroundColor: "rgba(255,255,255,0.95)",
              width: screenWidth > 500 ? 400 : "90%",
            },
          ]}
          elevation={4}
        >
          <SnackAutenticacion />
        </Card>

        {/* Copyright */}
        <SnackCopyright company="Maobits" url="https://www.maobits.com" />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  topBackground: {
    height: 240,
    borderBottomLeftRadius: 80,
    borderBottomRightRadius: 80,
    justifyContent: "center",
    alignItems: "center",
  },
  content: {
    flex: 1,
    marginTop: -80,
    alignItems: "center",
    paddingHorizontal: 20,
    justifyContent: "center",
  },
  card: {
    padding: 24,
    borderRadius: 20,
  },
});
